public enum State {
    /**
     * Stage of virus onset in Person
     */
    HEALTH, INFECTED, RECOVERY, DEATH, SEVERE
}
